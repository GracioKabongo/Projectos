package Vendas;
public class DadosVenda {
    
}
