package view;

import serverside.ChatServer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Server extends JFrame implements ActionListener{

    private JButton turnOn, turnOff;
    private JLabel serverStatus, serverIp;
    private JTextField fieldPort;
    private GridBagConstraints constraints;
    private ChatServer server;

    static boolean status;

    public Server(){
        initComponents();
        this.setVisible(true);
    }


    public void initComponents() {
        this.setTitle("Servidor de Chat");
        this.setSize(300, 250);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new GridBagLayout());


        constraints = new GridBagConstraints();
        turnOn = new JButton("Ligar");
        turnOff = new JButton("Desligar");
        turnOff.setEnabled(false);
        fieldPort = new JTextField(8);
        fieldPort.setText("4400");
        fieldPort.setEditable(false);
        fieldPort.setAlignmentX(CENTER_ALIGNMENT);
        serverStatus = new JLabel("Disconectado!");
        serverIp = new JLabel();

        // eventos
        turnOn.addActionListener(this);
        turnOff.addActionListener(this);


        constraints.anchor = GridBagConstraints.CENTER;
        constraints.insets = new Insets(5,5,5,5);


        addComponent(fieldPort, 0 ,0,2,1);
        addComponent(turnOn, 1,0,1,1);
        addComponent(turnOff, 1,1,1,1);
        addComponent(serverIp, 2,0,2,1);
        addComponent(serverStatus, 3,0,2,1);
    }

    private void addComponent(Component component, int row, int column, int width, int height){
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = width;
        constraints.gridheight = height;
        this.add(component, constraints);
    }

    public void startServer(int porta) {
        server = new ChatServer();

            new Thread(() -> {
                try {
                    if(server.isCosed())
                        server.start(porta);
                } catch (IOException e) {
                    //
                }
            }).start();

    }



    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == turnOn) {
            try {
                int porta = Integer.parseInt(fieldPort.getText());
                startServer(porta);
                this.turnOn.setEnabled(false);
                this.turnOff.setEnabled(true);
                serverStatus.setText("Ligado");
                serverStatus.updateUI();

                serverIp.setText(server.getAddress());
                serverIp.updateUI();
            } catch (NumberFormatException ex) {
                //
            }

        } if(e.getSource() == turnOff) {
            Thread.currentThread().interrupt();

            try {
                server.closeServer();
                this.turnOn.setEnabled(true);
                this.turnOff.setEnabled(false);
                serverStatus.setText("Desligado");
                serverIp.setText("");
                serverIp.updateUI();
                serverStatus.updateUI();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


    public static void main(String[] args) {
        new Server();
    }

}

